<?php
/**
 * Plugin Name: TTSarticles 
 * Plugin URI: https://yourwebsite.com
 * Description: This plugin creates a button for all admins on a wordpress webste that allows them to make a podcast out of their article.
 * Version: 2.0
 * Author: FilBlack
 * Author URI: https://yourwebsite.com
 */
function my_first_shortcode() {
    return "Hello world";
};
add_shortcode('hello_world','my_first_shortcode');

